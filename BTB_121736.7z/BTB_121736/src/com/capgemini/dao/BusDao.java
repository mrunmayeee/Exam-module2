package com.capgemini.dao;

import java.util.ArrayList;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;

public interface BusDao {

	ArrayList<BusBean> retrieveBusDetails() ;
	int bookTicket(BookingBean bookingBean)throws BookingException;
	
}
