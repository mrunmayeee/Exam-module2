package com.capgemini.dao;

import com.capgemini.bean.BookingBean;

public interface BookingDao {

	public int insertBookingDetails(BookingBean bookingBean);
}
