package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.util.JdbcUtil;

public class BookingDaoImpl implements BookingDao {

	Connection con;
	PreparedStatement ps;
	ResultSet rs;

	private static final Logger mylogger = Logger
			.getLogger(BookingDaoImpl.class);

	public int insertBookingDetails(BookingBean bookingBean) {

		int rec = 0;
		String query = "Insert into BookingDetails values(Booking_Id_Seq.NEXTVAL,?,?,?)";

		try {
			mylogger.info("Data successfully inserted");
			con = JdbcUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setString(1, bookingBean.getCustId());
			ps.setInt(2, bookingBean.getBusId());
			ps.setInt(3, bookingBean.getNoOfSeat());
			rec = ps.executeUpdate();
			if (rec > 0) {
				System.out.println("Insertion successful");
				return bookingBean.getBookingId();
			}


		} catch (BookingException e1) {
			e1.printStackTrace();
		} catch (SQLException e) {
			mylogger.error("Data not inserted");
			e.printStackTrace();
		}
		System.out.println("Insertion unsuccessful");
		return bookingBean.getBookingId();
	}
}
