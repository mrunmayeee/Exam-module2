package com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.util.JdbcUtil;

public class BusDaoImpl implements BusDao {
	Connection con;
	PreparedStatement ps;
	ResultSet rs;

	BusBean busBean = new BusBean();
	BookingBean bookingBean = new BookingBean();
	private static final Logger mylogger = Logger.getLogger(BusDaoImpl.class);

	public ArrayList<BusBean> retrieveBusDetails() {

		try {
			con = JdbcUtil.getConnection();
		} catch (BookingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String query = "SELECT * FROM BusDetails";
		ArrayList<BusBean> bList = new ArrayList<BusBean>();

		try {
			mylogger.info("Successful");
			ps = con.prepareStatement(query);
			rs = ps.executeQuery();
			while (rs.next()) {
				int busId = rs.getInt(1);
				String busType = rs.getString(2);
				String fromStop = rs.getString(3);
				String toStop = rs.getString(4);
				int fare = rs.getInt(5);
				int availableSeats = rs.getInt(6);
				Date dateOfJourney = rs.getDate(7);
				BusBean bb = new BusBean();

				bb.setBusId(busId);
				bb.setBusType(busType);
				bb.setFromStop(fromStop);
				bb.setToStop(toStop);
				bb.setFare(fare);
				bb.setAvailableSeats(availableSeats);
				bb.setDateOfJourney(dateOfJourney);

				bList.add(bb);
				
				

			}
		} catch (SQLException e) {
			mylogger.error("Not successful");
			e.printStackTrace();
		} finally {}
		return bList;
	}

	public int bookTicket(BookingBean bookingBean) throws BookingException {
		con = JdbcUtil.getConnection();
		String custId = bookingBean.getCustId();
		int busId = bookingBean.getBookingId();
		if (getBusId(busId)) {
			int seats = bookingBean.getNoOfSeat();
			System.out.println("----------->"+seats);

			int availSeats = getSeatAvailable(busId);
			System.out.println("--->"+availSeats);
			if (availSeats > 0 && seats < availSeats) {

				int s = availSeats-seats;
				String query = "UPDATE BusDetails SET availableSeats =? WHERE busId=?";
				try {
					mylogger.info("Successfully Updated");
					ps = con.prepareStatement(query);
					ps.setInt(1, s);
					ps.setInt(2, busId);
					System.out.println(seats+" ----------"+busId);
					int rec = ps.executeUpdate();
					if(rec>0){
						return busId;
					}
				} catch (SQLException e) {
					mylogger.error("Data not updated");
					e.printStackTrace();
					throw new BookingException("Data not found");
				} finally {}

				System.out.println("Thank You. Your booking id is ");

			} else {
				System.out.println("Sorry No Seats Available");
			}
		} else {
			System.out.println("Bus Id does not exist");
		}
		return busId;
	}

	public int getSeatAvailable(int busId) throws BookingException {
		con = JdbcUtil.getConnection();
		int availSeats = 0;
		String query = "SELECT availableSeats FROM BusDetails WHERE busID=?";
		try {
			ps = con.prepareStatement(query);
			ps.setInt(1, busId);
			rs = ps.executeQuery();
			while (rs.next()) {
				availSeats = rs.getInt(1);

			}
		} catch (SQLException e) {
			mylogger.error("Not successful");
			e.printStackTrace();
			throw new BookingException("Data not found");
		} finally {
			try {
				rs.close();
			//	ps.close();
			//	con.close();
			} catch (SQLException e) {
				e.printStackTrace();

			}
		}

		return availSeats;

	}

	public boolean getBusId(int busId) throws BookingException {

		con = JdbcUtil.getConnection();

		String query = "SELECT busId FROM BusDetails WHERE busID=?";
		try {
			ps = con.prepareStatement(query);
			ps.setInt(1, busId);
			rs = ps.executeQuery();
			if (rs.next()) {
				return true;

			}
		} catch (SQLException e) {
			mylogger.error("Not successful");
			e.printStackTrace();
			throw new BookingException("Data not found");
		} finally {}

		return false;
	}

}