package com.capgemini.client;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.service.BookingService;
import com.capgemini.service.BookingServiceImpl;
import com.capgemini.service.BusService;
import com.capgemini.service.BusServiceImpl;

public class MainClient {

	public static void main(String[] args) throws BookingException {

		BusService bs = new BusServiceImpl();

		BookingService bos = new BookingServiceImpl();
		BookingBean bookingBean = new BookingBean();

		Scanner sc = new Scanner(System.in);

		int choice = 0;
		do {
			printDetails();
			System.out.println("Enter choice: ");
			choice = sc.nextInt();

			switch (choice) {
			case 1:// show all
				ArrayList<BusBean> bus = new ArrayList<>();
				//BusBean bb1 = new BusBean();
				System.out.println("-----------------------------------------------------------------------------");
				System.out.printf("%10s %30s %20s %5s %5s", "BUS ID", "BUS TYPE", "DATE", "FROM", "TO","Available");
				System.out.println();
				System.out.println("-----------------------------------------------------------------------------");
				
					System.out.format("%10s %30s %20s %5d %5c", 
							bs.retrieveBusDetails());
					System.out.println();
				
				System.out.println("-----------------------------------------------------------------------------");
				System.out.println("Bus ID");
				
				//System.out.printf(format, bs.retrieveBusDetails());
				break;

			case 2: // insert
				BookingBean bb = new BookingBean();
				System.out.println("Enter customer id: ");
				String custId = sc.next();
				Pattern patt = Pattern.compile("^[A-Z]{1}[0-9]{6}$");
				Matcher cust1 = patt.matcher(custId);
				if (!cust1.matches()) {
					throw new BookingException(
							"ID should start with A-Z and then 6 digits");
				} else {
					bb.setCustId(custId);
					System.out.println("Enter bus id:");
					int busId = sc.nextInt();
					bb.setBusId(busId);
					System.out.println("Enter no of seats:");
					int seats = sc.nextInt();
					bb.setNoOfSeat(seats);

					int busid = bos.insertBookingDetails(bb);
					System.out.println("Bus ID: " + busid);

				}
				break;

			case 3: // update 

				System.out.println("Enter customer id:");
				String customerId = sc.next();
				Pattern pattern = Pattern.compile("^[A-Z]{1}[0-9]{6}$");
				Matcher customer1 = pattern.matcher(customerId);
				if (!customer1.matches()) {
					throw new BookingException(
							"ID should start with A-Z and then 6 digits");
				}
				else{
				bookingBean.setCustId(customerId);
				System.out.println("Enter bus id:");
				bookingBean.setBookingId(sc.nextInt());

				System.out.println("Enter no of seats:");
				bookingBean.setNoOfSeat(sc.nextInt());
				int busId = bs.bookTicket(bookingBean);
				System.out.println("Bus id:" + busId);
				}
				break;

			case 4:
				break;

			default:
				System.out.println("Invalid Choice");
			}

		} while (choice != 4);
		sc.close();
	}

	private static void printDetails() {

		System.out.println("**********");
		System.out.println("1. Show Bus Details");
		System.out.println("2. Booking register");
		System.out.println("3. Book Ticket");
		System.out.println("4. Exit");
		System.out.println("***********");

	}
	
	
	

}
