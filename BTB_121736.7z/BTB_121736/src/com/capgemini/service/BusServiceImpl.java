package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;

public class BusServiceImpl implements BusService {

	BusDaoImpl bd = new BusDaoImpl();
	public ArrayList<BusBean> retrieveBusDetails() {
		return bd.retrieveBusDetails();
	}

	public int bookTicket(BookingBean bookingBean) throws BookingException {
		return bd.bookTicket(bookingBean);
	}

}
