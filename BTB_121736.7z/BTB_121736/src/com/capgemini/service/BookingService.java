package com.capgemini.service;

import com.capgemini.bean.BookingBean;

public interface BookingService {


	public int insertBookingDetails(BookingBean bookingBean);
}
