package com.capgemini.service;

import com.capgemini.bean.BookingBean;
import com.capgemini.dao.BookingDao;
import com.capgemini.dao.BookingDaoImpl;

public class BookingServiceImpl implements BookingService{
	
BookingDao bd = new BookingDaoImpl();
	public int insertBookingDetails(BookingBean bookingBean) {
		return bd.insertBookingDetails(bookingBean);
	}

}
