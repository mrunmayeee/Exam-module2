package com.capgemini.junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;

public class BusBookTicketTest {
	BusDao busdao;
	BookingBean bookingBean;
	@Before
	public void setUp() throws Exception {
		busdao = new BusDaoImpl();
	 bookingBean = new BookingBean();
		bookingBean.setCustId("A123456");
		bookingBean.setBookingId(1);
		bookingBean.setNoOfSeat(5);
	}

	@After
	public void tearDown() throws Exception {
		busdao=null;
	}

	@Test
	public void testBookTicket() throws BookingException {
		assertNotNull(busdao.bookTicket(bookingBean));
	}

}
