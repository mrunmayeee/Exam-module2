package com.capgemini.junit;

import static org.junit.Assert.*;

import java.util.Calendar;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.dao.BookingDaoImpl;

public class BookingInsertTest {

	BookingDaoImpl bdi=null;
	BookingBean bb=null;
	@Before
	public void beforeTest(){
		bdi=new BookingDaoImpl();
		bb=new BookingBean();
		bb.setBusId(1);
		bb.setCustId("A123456");
		bb.setNoOfSeat(5);
	
	}
	@Test
	public void doTest() throws BookingException{
		assertEquals(bb.getBookingId(), bdi.insertBookingDetails(bb));
	}
	@After
	public void afterTest(){
		bdi=null;
		bb=null;
	}

}
