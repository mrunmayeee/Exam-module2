package com.capgemini.junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;

public class BusRetrieveTest {

	BusDao busdao;
	@Before
	public void setUp() throws Exception {
		busdao = new BusDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		busdao=null;
	}

	@Test
	public void testRetrieveBusDetails() {


		assertNotNull(busdao.retrieveBusDetails());
	}

}
