package com.capgemini.Exception;

public class BookingException extends Exception{

	public BookingException(String msg) {
		super(msg);
	}
}
