package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;

public interface BusService {
	
	ArrayList<BusBean> retrieveBusDetails();
	int BookTicket(BookingBean bookingBean)throws BookingException;

}
