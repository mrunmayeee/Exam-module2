package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.exception.BookingException;

public class BusServiceImpl implements BusService {
BusDaoImpl bus=new BusDaoImpl();
	@Override
	public ArrayList<BusBean> retrieveBusDetails() {
		// TODO Auto-generated method stub
		return bus.retrieveBusDetails();
	}

	@Override
	public int BookTicket(BookingBean bookingBean) throws BookingException {
		// TODO Auto-generated method stub
		return bus.BookTicket(bookingBean);
	}

}
