package com.capgemini.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.bean.BookingBean;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.exception.BookingException;
import com.capgemini.service.BusServiceImpl;

public class BusDaoBook_TicketTest {
	BookingBean detailsBean = new BookingBean(1, 4, "A123456");
	BusServiceImpl busService = new BusServiceImpl();
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	
	
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testBookTicket() {
		
		
		try {
			int a=busService.BookTicket(detailsBean);
			assertNotNull(a);
			System.out.println("Thank You.  Your Booking  Id is " + a);
		} catch (BookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
