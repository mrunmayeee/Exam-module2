package com.capgemini.exception;

public class BookingException extends Exception{
	public BookingException() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	public BookingException(String msg){
		super(msg);
	}
}
