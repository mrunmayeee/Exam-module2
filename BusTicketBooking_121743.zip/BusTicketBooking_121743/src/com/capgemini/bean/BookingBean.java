/*********************************************************************
 * Author Name          : NIKHIL PANDEY
 * Desc                 : JAVA
 * Version              : 1.0
 * Creation Date        : 01-Mar-2017
 * Last Modified Date   : 01-Mar-2017
 *********************************************************************/
package com.capgemini.bean;

public class BookingBean {
	private int bookingId;
	private int noOfSeat;
	private int busid;
	private String custid;

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public int getNoOfSeat() {
		return noOfSeat;
	}

	public void setNoOfSeat(int noOfSeat) {
		this.noOfSeat = noOfSeat;
	}

	public int getBusid() {
		return busid;
	}

	public void setBusid(int busid) {
		this.busid = busid;
	}

	public String getCustid() {
		return custid;
	}

	public void setCustid(String custid) {
		this.custid = custid;
	}

	public BookingBean( int noOfSeat, int busid, String custid) {
		super();
	
		this.noOfSeat = noOfSeat;
		this.busid = busid;
		this.custid = custid;
	}

	public BookingBean() {
		// TODO Auto-generated constructor stub
	}

}
