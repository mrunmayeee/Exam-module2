/*********************************************************************
 * File                 : MainClient.java
 * Author Name          : NIKHIL PANDEY
 * Desc                 : JAVA
 * Version              : 1.0
 * Creation Date        : 01-Mar-2017
 * Last Modified Date   : 01-Mar-2017
 *********************************************************************/
package com.capgemini.client;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.capgemini.bean.BookingBean;
import com.capgemini.exception.BookingException;
import com.capgemini.service.BusServiceImpl;
public class MainClient {
	private static final Logger mylogger = Logger.getLogger(MainClient.class);

	public static void main(String[] args) {
		int bookingid = 0;
		mylogger.info("APPLICATION STARTED");
		Scanner sc = new Scanner(System.in);
		
		int choice = 0;
		do {	BusServiceImpl busService = new BusServiceImpl();
			printDetail();
			choice = sc.nextInt();
			switch (choice) {
			case 1:
			
				System.out.println(busService.retrieveBusDetails());
break;
			case 2:
				Scanner scanner = new Scanner(System.in);
				System.out.println("ENTER Custmert ID");
				String id = scanner.nextLine();
				
		//////////////////////////
				
				Pattern p = Pattern.compile("^[A-Z]{1}[0-9]{6}");
				Matcher m = p.matcher(id);
				if (!m.find()) {
					try {

						throw new BookingException(
								"\nENTER CORRECT ID\n ");
						

					} catch (BookingException e) {
						// TODO Auto-generated catch block

						e.printStackTrace();
					} 
					finally {
						try {
							Thread.currentThread().sleep(100);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						break;

					}
				}
		/////////////////////////
				
				System.out.println("ENTER No of Seat");
				int seat = scanner.nextInt();						
				System.out.println("ENTER Bus id");
				int bus = scanner.nextInt();
				BookingBean detailsBean = new BookingBean(seat, bus, id);
				try {
					bookingid = busService.BookTicket(detailsBean);
				} catch (BookingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (bookingid > 0) {
					System.out.println("Thank You.  Your Booking  Id is " + bookingid);
				} else {
				}
				break;
			case 3:	mylogger.info("APPLICATION CLOSED");
				System.exit(0);
				break;
			}

		// TODO Auto-generated method stub

	}while (choice != 3);
	
		System.exit(0);

	}
	public static void printDetail() {
		System.out.println("**********");
		System.out.println("1. Show Bus Details ");
		System.out.println("2. Book Ticket");
		System.out.println("3. Exit");
		System.out.println("***********");
	}
	
}
