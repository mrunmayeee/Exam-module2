package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;
import com.capgemini.util.JdbcUtill;

public class BusDaoImpl implements BusDao {

	Connection con = null;
	PreparedStatement pst;

	private static final Logger mylogger = Logger.getLogger(BusDaoImpl.class);

	@Override
	public ArrayList<BusBean> retrieveBusDetails() {
		mylogger.info("Showing Information.....");
		try {
			con = JdbcUtill.JdbcUtil();
		} catch (BookingException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		String Query = "select * from BusDetails";

		List<BusBean> list = new ArrayList<BusBean>();
		try {
			pst = con.prepareStatement(Query);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				int busId = rs.getInt("busId");
				String busType = rs.getString("busType");
				String fromStop = rs.getString("fromStop");
				String toStop = rs.getString("toStop");
				java.sql.Date dateString = rs.getDate("dateOfJourney");

				LocalDate date = dateString.toLocalDate();

				int availableSeats = rs.getInt("availableSeats");
				int fare = rs.getInt("fare");
			
				BusBean m = new BusBean();
				m.setBusid(busId);
				m.setBusType(busType);
				m.setFromStop(fromStop);
				m.setToStop(toStop);
				m.setFare(fare);
				m.setAvailableSeats(availableSeats);
				// ///////////////////////////////////////

				// //////////////////////////////
				m.setDateOfJourney(date);
				list.add(m);
				// ////////////////////////////////////

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			try {
				throw new BookingException("DATA NOT FOUND");
			} catch (BookingException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			// throw user defined exception
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		// TODO Auto-generated method stub
		return (ArrayList<BusBean>) list;

	}

	@Override
	public int BookTicket(BookingBean bookingBean) throws BookingException {
		// TODO Auto-generated method stub
		int availableSeats = 0;
		Long bookingId = null;
		Scanner sc = new Scanner(System.in);

		try {
			con = JdbcUtill.JdbcUtil();
		} catch (BookingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		// /////////////////////////

		String Query = "select *  from BusDetails where busId=?  ";
		try {
		
			int seat = bookingBean.getNoOfSeat();
			pst = con.prepareStatement(Query);
			pst.setInt(1, bookingBean.getBusid());
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				availableSeats = rs.getInt("availableSeats");
			}

			int total = availableSeats - seat;
			if (total <= 0) {
				System.out.println("Sorry No Seats Available");
			} else {
				try {

					String Query1 = "insert into BookingDetails values(Booking_Id_Seq.nextval,?,?,?) ";
					pst = con.prepareStatement(Query1);
					pst.setString(1, bookingBean.getCustid());
					pst.setInt(2, bookingBean.getBusid());
					pst.setInt(3, bookingBean.getNoOfSeat());

					ResultSet rs1 = pst.executeQuery();

					BusDaoImpl busDaoImpl = new BusDaoImpl();
					boolean rs11 = busDaoImpl.updateSeat(
							bookingBean.getBusid(), (availableSeats - seat));

					if (rs11) {// /////////////////////////////////////////

						String Queryid = "select Booking_Id_Seq.currval as  from dual";
						try {
							pst = con.prepareStatement(Queryid);
							mylogger.info("TICKET BOOKED.....");
							ResultSet rsid = pst.executeQuery();
							while (rsid.next()) {
								bookingId = rsid.getLong(1);
							}
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} finally {
						}

						// //////////////////////////////////////////////
					}

				} catch (BookingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (bookingId == null) {
			return 0;
		}

		return bookingId.intValue();
	}

	// //////////////////////

	// /////////////////////////

	public boolean updateSeat(int busid, int seat) throws BookingException {
		// TODO Auto-generated method stub

		con = JdbcUtill.JdbcUtil();
		int rec = 0;
		String Query = "update BusDetails set availableSeats=? where busId=? ";
		try {
			pst = con.prepareStatement(Query);
			pst.setInt(1, seat);
			pst.setInt(2, busid);
			rec = pst.executeUpdate();
			if (rec > 0) {
				return true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;

	}

	// /////////////////

}
