package com.capgemini.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.capgemini.exception.BookingException;


public class JdbcUtill  {
	private static final Logger mylogger = Logger.getLogger(JdbcUtill.class);

	public static Properties GetPro() {
		Properties p = new Properties();
		try {
			FileInputStream fileInputStream = new FileInputStream(
					"oracle.properties");
			p.load(fileInputStream);

			// System.out.println(p.getProperty("oracle.uname"));
		} catch (FileNotFoundException e) { // TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) { // TODO Auto-generated
			e.printStackTrace();
		}
		return p;
	}

	public static Connection JdbcUtil () throws BookingException {
		Connection con = null;
		Properties p = GetPro();
		try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		//	String url1 = "jdbc:oracle:thin:@10.125.6.62:1521:ORCL11G";
		//	con = DriverManager.getConnection(url1, "labg104trg38",
			//		"labg104oracle");
	//	System.out.println(p.getProperty("oracle.url")+" "+p.getProperty("oracle.uname")+" "+p.getProperty("oracle.upass"));
con=DriverManager.getConnection(p.getProperty("oracle.url"),p.getProperty("oracle.uname"),p.getProperty("oracle.upass"));
			
if(con!=null)
{
	mylogger.info("Coneection Esablished.....");
	}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			mylogger.error("Coneection Not Esablished....." + e);
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			mylogger.error("Coneection Not Esablished....." + e);
			e.printStackTrace();
		}
		return con;

	}

}
