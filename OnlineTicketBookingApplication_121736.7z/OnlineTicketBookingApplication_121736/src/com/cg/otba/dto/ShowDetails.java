package com.cg.otba.dto;

import java.util.Date;

public class ShowDetails {

	private String showId;
	private String showName;
	private String location;
	private Date showDate;
	private int avseats;
	private double priceTicket;
	
	
	private int bookSeats;
	
	private String name;
	private int mobile;
	private int bookedSeats;
	public int getBookedSeats() {
		return bookedSeats;
	}
	public void setBookedSeats(int bookedSeats) {
		this.bookedSeats = bookedSeats;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public int getBookSeats() {
		return bookSeats;
	}
	public void setBookSeats(int bookSeats) {
		this.bookSeats = bookSeats;
	}
	public ShowDetails() {
		super();
	}
	public ShowDetails(String showId, String showName, String location,
			Date showDate, int avseats, double priceTicket) {
		super();
		this.showId = showId;
		this.showName = showName;
		this.location = location;
		this.showDate = showDate;
		this.avseats = avseats;
		this.priceTicket = priceTicket;
	}
	public String getShowId() {
		return showId;
	}
	public void setShowId(String showId) {
		this.showId = showId;
	}
	public String getShowName() {
		return showName;
	}
	public void setShowName(String showName) {
		this.showName = showName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Date getShowDate() {
		return showDate;
	}
	public void setShowDate(Date showDate) {
		this.showDate = showDate;
	}
	public int getAvseats() {
		return avseats;
	}
	public void setAvseats(int avseats) {
		this.avseats = avseats;
	}
	public double getPriceTicket() {
		return priceTicket;
	}
	public void setPriceTicket(double priceTicket) {
		this.priceTicket = priceTicket;
	}
	@Override
	public String toString() {
		return "ShowDetails [showId=" + showId + ", showName=" + showName
				+ ", location=" + location + ", showDate=" + showDate
				+ ", avseats=" + avseats + ", priceTicket=" + priceTicket + "]";
	}
	
	
}
