package com.cg.otba.dao;

import java.util.List;

import com.cg.otba.dto.ShowDetails;
import com.cg.otba.exception.ShowException;

public interface IShowDao {

	List<ShowDetails> show() throws ShowException;
	
	public boolean updateSeats(ShowDetails showdetails) throws ShowException;
	
	public ShowDetails getShowDetails(String id);
}
