package com.cg.otba.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;




import com.cg.otba.dto.ShowDetails;
import com.cg.otba.exception.ShowException;
import com.cg.otba.util.DBUtil;

public class ShowDaoImpl implements IShowDao {

	@Override
	public List<ShowDetails> show() throws ShowException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<ShowDetails> myList = new ArrayList<>();
		String query = "select showid,showname,location,showdate,avseats,priceticket from showdetails";
		try {
			con = DBUtil.obtainConnection();
			ps = con.prepareStatement(query);
			rs = ps.executeQuery();
			while (rs.next()) {
				ShowDetails showdetails = new ShowDetails();

				showdetails.setShowId(rs.getString("showid"));
				showdetails.setShowName(rs.getString("showname"));
				showdetails.setLocation(rs.getString("location"));
				showdetails.setShowDate(rs.getDate("showdate"));
				showdetails.setAvseats(rs.getInt("avseats"));
				showdetails.setPriceTicket(rs.getDouble("priceticket"));

				myList.add(showdetails);
			}
		} catch (SQLException e) {
			throw new ShowException("Problem in show");
		} finally {
			try {
				rs.close();
				ps.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return myList;
	}

	@Override
	public boolean updateSeats(ShowDetails showdetails) throws ShowException {
		//System.out.println("------------->");
		int seats = 0;
		double price;
		System.out.println(showdetails.getShowId());
		int avseats = showdetails.getAvseats();
		int bookseats = showdetails.getBookSeats();
		if (avseats >= bookseats) {
			seats = avseats-bookseats;
			price = showdetails.getPriceTicket()*bookseats;
			//System.out.println(price);
			//System.out.println(showdetails.getPriceTicket()+"--------->");
			//System.out.println(seats);

			//System.out.println(showdetails.getShowName());
			String query = "update showdetails set avseats=?,priceticket=? where showname=?";
			Connection con = null;
			PreparedStatement ps = null;
			// ResultSet rs = null;
			int rec = 0;
			// List<Employee> myList = new ArrayList<>();

			try {
				con = DBUtil.obtainConnection();
				ps = con.prepareStatement(query);

				ps.setInt(1, seats);
				ps.setDouble(2, price);
				ps.setString(3, showdetails.getShowName());

				rec = ps.executeUpdate();
				System.out.println(rec);
				if (rec > 0) {

					return true;
				}
				/*
				 * else{ System.out.println("unSuccessfully Updated"); }
				 */
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new ShowException("Not updated");
			}

			
		}
		return false;
	}
	
	public ShowDetails getShowDetails(String id) {
		String query="select showid,showname,location,showdate,avseats,priceticket from showdetails where showid=?";
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ShowDetails sd = new ShowDetails();
		try {
			con=DBUtil.obtainConnection();
			ps=con.prepareStatement(query);
			ps.setString(1, id);
			rs=ps.executeQuery();
			while(rs.next()){
				
				sd.setShowName(rs.getString("showname"));
				sd.setPriceTicket(rs.getDouble("priceticket"));
				sd.setAvseats(rs.getInt("avseats"));
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sd;
	}
	
}
