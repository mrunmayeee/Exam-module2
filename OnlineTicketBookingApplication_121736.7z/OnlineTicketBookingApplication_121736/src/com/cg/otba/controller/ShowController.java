package com.cg.otba.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.otba.dto.ShowDetails;
import com.cg.otba.exception.ShowException;
import com.cg.otba.service.IShowService;
import com.cg.otba.service.ShowServiceImpl;

@WebServlet("*.do")
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	IShowService service;

	public ShowController() {
		service = new ShowServiceImpl();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String path = request.getServletPath();
		System.out.println(path);
		ShowDetails showdetails = new ShowDetails();
		String display = null;
		if (path.equals("/Show.do")) {
			List<ShowDetails> myList = new ArrayList<>();

			try {
				myList = service.show();
			} catch (ShowException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			request.setAttribute("data", myList);

			RequestDispatcher rd = request
					.getRequestDispatcher("showDetails.jsp");
			rd.forward(request, response);

		}

		else if (path.equals("/bookUpdate.do")) {
			String showId = request.getQueryString().substring(3, 7);

			System.out.println(showId);

			ShowDetails showdetails1 = service.getShowDetails(showId);
			System.out.println(showdetails1);
			request.setAttribute("datas", showdetails1);
			RequestDispatcher rd = request.getRequestDispatcher("bookNow.jsp");
			rd.forward(request, response);

		}

		else if (path.equals("/bookNow.do")) {

			//String showId = request.getQueryString().substring(3, 7);
			String showName = request.getParameter("sName");
			System.out.println(showName);
			double ticket = Double.parseDouble(request.getParameter("sPrice"));
			String cName = request.getParameter("cName");
			int mobileNo = Integer.parseInt(request.getParameter("mob"));
			int seats = Integer.parseInt(request.getParameter("seats"));

			int bookSeats = Integer.parseInt(request.getParameter("bookseats"));

			//showdetails.setShowId(showId);
			showdetails.setShowName(showName);
			showdetails.setName(cName);
			showdetails.setMobile(mobileNo);
			showdetails.setPriceTicket(ticket);
			showdetails.setAvseats(seats);
			showdetails.setBookSeats(bookSeats);

			try {
				if (service.updateSeats(showdetails)) {

					request.setAttribute("dataname", showdetails.getShowName());
					request.setAttribute("dataname1", showdetails.getName());
					request.setAttribute("dataname2", showdetails.getMobile());
					request.setAttribute("dataname3",
							showdetails.getBookSeats());
					request.setAttribute("dataname4",
							showdetails.getPriceTicket());

					RequestDispatcher rd = request
							.getRequestDispatcher("success.jsp");
					rd.forward(request, response);
				} else {
					RequestDispatcher rd = request
							.getRequestDispatcher("error.jsp");
					rd.forward(request, response);
				}
			} catch (ShowException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} else if (path.equals("success.do")) {

		}

	}
}
