package com.cg.otba.exception;

public class ShowException extends Exception{

	public ShowException(){
		super();
	}
	
	public ShowException(String msg){
		super(msg);
	}
}
