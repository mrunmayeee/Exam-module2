package com.cg.otba.service;

import java.util.List;

import com.cg.otba.dto.ShowDetails;
import com.cg.otba.exception.ShowException;

public interface IShowService {

	public List<ShowDetails> show() throws ShowException;
	
	public boolean updateSeats(ShowDetails showdetails) throws ShowException ;
	
	public ShowDetails getShowDetails(String id);
}
