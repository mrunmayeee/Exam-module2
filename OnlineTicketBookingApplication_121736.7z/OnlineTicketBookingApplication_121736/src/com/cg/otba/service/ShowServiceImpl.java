;package com.cg.otba.service;

import java.util.List;

import com.cg.otba.dao.IShowDao;
import com.cg.otba.dao.ShowDaoImpl;
import com.cg.otba.dto.ShowDetails;
import com.cg.otba.exception.ShowException;

public class ShowServiceImpl implements IShowService {

	
	IShowDao dao;
	public ShowServiceImpl(){
	 dao = new ShowDaoImpl();
	}
	
	@Override
	public List<ShowDetails> show() throws ShowException {
		
		return dao.show();
	}

	@Override
	public boolean updateSeats(ShowDetails showdetails) throws ShowException {
		// TODO Auto-generated method stub
		return dao.updateSeats(showdetails);
	}

	@Override
	public ShowDetails getShowDetails(String id) {
		// TODO Auto-generated method stub
		return dao.getShowDetails(id);
	}

}
